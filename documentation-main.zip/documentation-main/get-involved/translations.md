# Translations

Fortress plans on making the website multilingual as to serve as many people as possible. Do you want to help in translating the website, or our medium articles? Contact us in our [discord](https://discord.gg/fortress/), or in our [telegram](https://t.me/FortressDAO/).
