# Links

## Official

* [Website](https://fortressdao.finance)
* [Twitter](https://twitter.com/FortressDAO/)
* [Medium](https://fortressdao.medium.com)
* [Discord](https://discord.gg/fortress/)
* [Telegram](https://t.me/FortressDAO/)
* [Github](https://github.com/Fortress-DAO)
* [Governance](https://snapshot.org/#/fortressdao.eth/)
