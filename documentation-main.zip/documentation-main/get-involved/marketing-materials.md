# Marketing Materials

### FORT LOGO

[https://app.fortressdao.finance/static/media/FORT.edeb70b4.svg](https://app.fortressdao.finance/static/media/FORT.edeb70b4.svg)

{% embed url="https://app.fortressdao.finance/static/media/FORT.edeb70b4.svg" %}

### sFORT LOGO

[https://app.fortressdao.finance/static/media/SFORT.1be4459b.svg](https://app.fortressdao.finance/static/media/SFORT.1be4459b.svg)

{% embed url="https://app.fortressdao.finance/static/media/SFORT.1be4459b.svg" %}

### Caricature Background

![](<../.gitbook/assets/image (2).png>)
