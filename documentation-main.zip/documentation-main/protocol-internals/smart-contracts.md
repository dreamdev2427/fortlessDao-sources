# Smart Contracts

### FORT

{% embed url="https://snowtrace.io/token/0xf6d46849db378ae01d93732585bec2c4480d1fd5" %}

### Staked FORT - sFORT

{% embed url="https://snowtrace.io/token/0x6b8fb769d1957f2c29abc9d1beb95851cce775d8" %}

### Magic Internet Money (MIM)

{% embed url="https://snowtrace.io/token/0x130966628846bfd36ff31a822705796e8cb8c18d" %}

### Wrapped AVAX (wAVAX)

{% embed url="https://snowtrace.io/token/0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7" %}

### Staking

{% embed url="https://snowtrace.io/address/0x4d8ba74820e2d6ead2ea154586cb7dfba8a691aa" %}

### Treasury

{% embed url="https://snowtrace.io/address/0xb8e8d2e97c5f4594f65cce0f5888c641c7a3a056" %}

### Liquidity Bootstrap Event

{% embed url="https://snowtrace.io/address/0x82756cb8B251bfB10Acd7931756a1edb7f253850" %}
