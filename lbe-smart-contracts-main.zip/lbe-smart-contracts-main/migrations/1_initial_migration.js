const FORTSale = artifacts.require("FORTSale");

module.exports = function (deployer) {
  deployer.deploy(FORTSale);
};
